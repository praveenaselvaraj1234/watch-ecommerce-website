import React from 'react'
import "../App.css"

const PopularBrands = () => {
  return (
    <div className='popular-mainBox'>
       <div>
           <img src="/images/apple-watch-4028102_640.jpg" alt="" />
           <br />
            <center><button>ROLEX</button></center>
       </div>
        <div>
           <img src="/images/apple-watch-4028102_640.jpg" alt="" />
           <br />
              <center><button>IWC</button></center>
       </div>
        <div>
           <img src="/images/apple-watch-4028102_640.jpg" alt="" />
           <br />
              <center><button>HUBLOT</button></center>
       </div>
        <div>
           <img src="/images/apple-watch-4028102_640.jpg" alt="" />
           <br />
              <center><button>TEA HEUER</button></center>
       </div>
        <div>
           <img src="/images/apple-watch-4028102_640.jpg" alt="" />
           <br />
             <center> <button>ZENITH</button></center>
       </div>
        <div>
           <img src="/images/apple-watch-4028102_640.jpg" alt="" />
           <br />
              <center><button>OMEGA</button></center>
       </div>
    </div>
  )
}

export default PopularBrands