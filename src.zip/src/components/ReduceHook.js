import React from 'react'

const ReduceHook = () => {

  return (
    <div>ReduceHook</div>
  )
}

export default ReduceHook